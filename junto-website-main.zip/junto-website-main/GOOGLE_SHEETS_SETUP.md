# Google Sheets Backend Setup

Follow these steps to connect both forms to Google Sheets.

## Step 1: Create the Waitlist Sheet

1. Go to [Google Sheets](https://sheets.google.com) and create a new spreadsheet
2. Name it **"Junto Waitlist"**
3. In Row 1, add these headers: `Timestamp | Full Name | Email | Device | University | City`
4. Go to **Extensions > Apps Script**
5. Delete any existing code and paste:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  sheet.appendRow([
    data.timestamp,
    data.fullName,
    data.email,
    data.device,
    data.university,
    data.city
  ]);
  return ContentService.createTextOutput(JSON.stringify({status: "success"}))
    .setMimeType(ContentService.MimeType.JSON);
}
```

6. Click **Deploy > New deployment**
7. Select type: **Web app**
8. Set "Execute as": **Me**
9. Set "Who has access": **Anyone**
10. Click **Deploy** and copy the URL

## Step 2: Create the Complaints Sheet

1. Create another new spreadsheet named **"Junto Complaints"**
2. In Row 1, add these headers: `Timestamp | Category | Subject | Details | Email | Attachment`
3. Go to **Extensions > Apps Script**
4. Delete any existing code and paste:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  sheet.appendRow([
    data.timestamp,
    data.category,
    data.subject,
    data.details,
    data.email,
    data.attachment
  ]);
  return ContentService.createTextOutput(JSON.stringify({status: "success"}))
    .setMimeType(ContentService.MimeType.JSON);
}
```

5. Deploy the same way as Step 1 and copy the URL

## Step 3: Update index.html

Open `index.html` and find these two lines near the bottom:

```javascript
const WAITLIST_SHEET_URL = 'YOUR_WAITLIST_SCRIPT_URL';
const COMPLAINT_SHEET_URL = 'YOUR_COMPLAINT_SCRIPT_URL';
```

Replace them with your actual Apps Script URLs from Steps 1 and 2.

## Done!

Form submissions will now appear in your Google Sheets in real time.
